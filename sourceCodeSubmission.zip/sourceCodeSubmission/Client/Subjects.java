package com.coen445.FinalProject;

public abstract class Subjects {
    public static final String INTEREST1 = "1. Politics";
    public static final String INTEREST2 = "2. Sports";
    public static final String INTEREST3 = "3. Pop culture";
    public static final String INTEREST4 = "4. Weather";
    public static final String INTEREST5 = "5. Technology";

    public static final String INTEREST1_FOR_SERVER = "Politics";
    public static final String INTEREST2_FOR_SERVER = "Sports";
    public static final String INTEREST3_FOR_SERVER = "Pop culture";
    public static final String INTEREST4_FOR_SERVER = "Weather";
    public static final String INTEREST5_FOR_SERVER = "Technology";
}
